# Emoji data

Use `gen.js` to generate `emoji-data.json`.

Make sure to update `emoji-test.txt` to the latest version from here: https://unicode.org/Public/emoji/latest/emoji-test.txt

TODO: maybe include https://github.com/muan/emojilib/blob/main/dist/emoji-en-US.json to better filter emoji? Probably too big  
TODO: add regional indicators, they are not included in `emoji-test.txt`
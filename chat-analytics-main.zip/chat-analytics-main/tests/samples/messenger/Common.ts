import { PGuild } from "@pipeline/parse/Types";

export const PGUILD_DEFAULT: PGuild = {
    id: 0,
    name: "Messenger Chats",
};

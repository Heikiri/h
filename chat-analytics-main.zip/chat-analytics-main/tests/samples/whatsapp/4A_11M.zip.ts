// @ts-ignore
export * from "./4A_11M.txt.ts";
